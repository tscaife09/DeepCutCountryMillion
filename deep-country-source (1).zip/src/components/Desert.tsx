export function Desert() {
  return (
    <div className="pointer-events-none absolute inset-0 overflow-hidden">
      <img src="/desert.jpg" alt="" className="h-full w-full object-cover" />
      <div className="absolute inset-0 bg-gradient-to-b from-dusk/55 via-transparent to-dusk/55" />
    </div>
  );
}
