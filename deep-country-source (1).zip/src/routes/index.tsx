import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useRef, useState, type FormEvent } from "react";
import { BookOpen, Plus, Trash2 } from "lucide-react";
import { Desert } from "@/components/Desert";
import {
  DEFAULT_CODE,
  POINT_OPTIONS,
  ROUND_SECONDS,
  TIER_NAME,
  type Answer,
  type Bank,
  type Points,
  type Prompt,
  emptyBank,
  loadBank,
  loadCode,
  matchAnswer,
  playablePrompts,
  rankFor,
  saveBank,
  saveCode,
  uid,
} from "@/lib/trail";

export const Route = createFileRoute("/")({ component: App });

type Phase = "home" | "play" | "results" | "editor";
type Log = { prompt: string; answer: string; points: number; note: string };
type RoundResult = { logs: Log[]; score: number; max: number };

function App() {
  const [bank, setBank] = useState<Bank>(emptyBank);
  const [code, setCode] = useState(DEFAULT_CODE);
  const [phase, setPhase] = useState<Phase>("home");
  const [lockOpen, setLockOpen] = useState(false);
  const [result, setResult] = useState<RoundResult | null>(null);

  useEffect(() => {
    setBank(loadBank());
    setCode(loadCode());
  }, []);

  const prompts = useMemo(() => playablePrompts(bank), [bank]);

  function updateBank(next: Bank) {
    setBank(next);
    saveBank(next);
  }

  return (
    <main className="relative min-h-dvh overflow-hidden bg-dusk text-cream">
      <Desert />
      <div className="relative z-10 mx-auto flex min-h-dvh w-full max-w-3xl flex-col px-4 py-6 sm:px-6">
        {phase === "home" && (
          <HomeView
            count={prompts.length}
            onRide={() => {
              setResult(null);
              setPhase("play");
            }}
            onBook={() => setLockOpen(true)}
          />
        )}
        {phase === "play" && (
          <PlayView
            prompts={prompts}
            onDone={(round) => {
              setResult(round);
              setPhase("results");
            }}
            onQuit={() => setPhase("home")}
          />
        )}
        {phase === "results" && result && (
          <ResultsView result={result} onHome={() => setPhase("home")} />
        )}
        {phase === "editor" && (
          <Editor
            code={code}
            bank={bank}
            onChange={updateBank}
            onCode={(next) => {
              setCode(next);
              saveCode(next);
            }}
            onClose={() => setPhase("home")}
          />
        )}
      </div>
      {lockOpen && (
        <Lock
          expected={code}
          onClose={() => setLockOpen(false)}
          onOk={() => {
            setLockOpen(false);
            setPhase("editor");
          }}
        />
      )}
    </main>
  );
}

function HomeView({
  count,
  onRide,
  onBook,
}: {
  count: number;
  onRide: () => void;
  onBook: () => void;
}) {
  return (
    <div className="flex flex-1 flex-col justify-between gap-8">
      <header className="pt-6 sm:pt-10">
        <p className="text-sm font-medium tracking-[0.22em] text-sand uppercase">
          Rare answers ride farther
        </p>
        <h1 className="mt-2 font-display text-5xl leading-none text-cream sm:text-7xl">
          Deep Country
        </h1>
        <p className="mt-4 max-w-md text-sand">
          One trail, the one you write in the trail book. Obvious answers barely
          leave camp. A rare one carries the rider out across the flats.
        </p>
      </header>
      <div className="mb-28 flex flex-col gap-3 sm:mb-36 sm:flex-row">
        <button
          type="button"
          disabled={count === 0}
          onClick={onRide}
          className="rounded-xl bg-clay px-6 py-3 text-lg font-semibold text-dusk disabled:opacity-40"
        >
          {count === 0 ? "Write the trail first" : `Ride · ${count} question${count === 1 ? "" : "s"}`}
        </button>
        <button
          type="button"
          onClick={onBook}
          className="inline-flex items-center justify-center gap-2 rounded-xl border border-sand/40 bg-ink/70 px-6 py-3 text-lg font-semibold text-cream"
        >
          <BookOpen size={18} /> Trail book
        </button>
      </div>
    </div>
  );
}

function Lock({
  expected,
  onClose,
  onOk,
}: {
  expected: string;
  onClose: () => void;
  onOk: () => void;
}) {
  const [value, setValue] = useState("");
  const [bad, setBad] = useState(false);

  function submit(e: FormEvent) {
    e.preventDefault();
    if (value.trim() === expected) onOk();
    else setBad(true);
  }

  return (
    <div className="fixed inset-0 z-30 grid place-items-center bg-dusk/75 px-4">
      <form onSubmit={submit} className="w-full max-w-sm rounded-2xl bg-ink p-5">
        <h2 className="font-display text-3xl">Trail book</h2>
        <p className="mt-1 text-sm text-sand">
          Enter the code to edit every question and answer.
          {expected === DEFAULT_CODE ? " The starting code is deepcut." : ""}
        </p>
        <input
          autoFocus
          value={value}
          onChange={(e) => {
            setValue(e.target.value);
            setBad(false);
          }}
          className="mt-4 w-full rounded-lg border border-line bg-dusk px-3 py-3 text-cream outline-none"
          placeholder="Code"
          autoComplete="off"
        />
        {bad && <p className="mt-2 text-sm text-clay">That code doesn’t open the book.</p>}
        <div className="mt-4 flex gap-2">
          <button type="submit" className="flex-1 rounded-lg bg-clay py-3 font-semibold text-dusk">
            Open
          </button>
          <button type="button" onClick={onClose} className="rounded-lg px-4 py-3 text-sand">
            Cancel
          </button>
        </div>
      </form>
    </div>
  );
}

function PlayView({
  prompts,
  onDone,
  onQuit,
}: {
  prompts: Prompt[];
  onDone: (result: RoundResult) => void;
  onQuit: () => void;
}) {
  const [index, setIndex] = useState(0);
  const [score, setScore] = useState(0);
  const [left, setLeft] = useState(ROUND_SECONDS);
  const [input, setInput] = useState("");
  const [note, setNote] = useState("");
  const [bad, setBad] = useState(false);
  const [locked, setLocked] = useState(false);
  const [riding, setRiding] = useState(false);
  const logs = useRef<Log[]>([]);
  const scoreRef = useRef(0);
  const indexRef = useRef(0);
  const lockedRef = useRef(false);
  const waitRef = useRef(0);
  const max = prompts.length * 100;

  useEffect(() => {
    indexRef.current = index;
    lockedRef.current = false;
    setLocked(false);
    setRiding(false);
    const deadline = performance.now() + ROUND_SECONDS * 1000;
    let frame = 0;
    let stopped = false;
    const tick = (now: number) => {
      if (stopped || lockedRef.current) return;
      const remain = Math.max(0, (deadline - now) / 1000);
      setLeft(remain);
      if (remain <= 0) {
        stopped = true;
        lockedRef.current = true;
        setLocked(true);
        logs.current.push({
          prompt: prompts[index]!.text,
          answer: "(time)",
          points: 0,
          note: "Time",
        });
        setBad(true);
        setNote("Time’s up.");
        waitRef.current = window.setTimeout(() => goNext(scoreRef.current), 800);
        return;
      }
      frame = requestAnimationFrame(tick);
    };
    frame = requestAnimationFrame(tick);
    return () => {
      stopped = true;
      cancelAnimationFrame(frame);
      window.clearTimeout(waitRef.current);
    };
    // fresh clock each question
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [index]);

  function goNext(nextScore: number) {
    const following = indexRef.current + 1;
    if (following >= prompts.length) {
      onDone({ logs: logs.current.slice(), score: nextScore, max });
      return;
    }
    setInput("");
    setNote("");
    setIndex(following);
  }

  function submit(e: FormEvent) {
    e.preventDefault();
    if (lockedRef.current) return;
    const text = input.trim();
    if (!text) return;
    const hit = matchAnswer(text, prompts[index]!.answers);
    if (!hit) {
      setBad(true);
      setNote("Not on this trail. Try again while the clock runs.");
      setInput("");
      return;
    }
    lockedRef.current = true;
    setLocked(true);
    const nextScore = scoreRef.current + hit.points;
    scoreRef.current = nextScore;
    setScore(nextScore);
    setRiding(true);
    setBad(false);
    const label = TIER_NAME[hit.points];
    setNote(hit.fuzzy ? `Close enough — counted as “${hit.canonical}”. ${label}.` : `${label}. +${hit.points}`);
    logs.current.push({
      prompt: prompts[index]!.text,
      answer: text,
      points: hit.points,
      note: hit.fuzzy ? `as ${hit.canonical}` : label,
    });
    waitRef.current = window.setTimeout(() => goNext(nextScore), 1000);
  }

  const seconds = Math.ceil(left);

  return (
    <div className="flex flex-1 flex-col">
      <div className="flex items-center justify-between text-sm">
        <span className="text-sand">
          {index + 1} / {prompts.length}
        </span>
        <span className={seconds <= 5 ? "font-semibold text-clay" : "font-semibold text-cream"}>
          {seconds}s
        </span>
        <span className="text-sand">{score * 10} miles</span>
      </div>
      <section className="mt-4 rounded-2xl bg-ink/85 p-5">
        <p className="text-xs tracking-[0.18em] text-sand uppercase">Name something</p>
        <h2 className="mt-1 font-display text-3xl leading-tight sm:text-4xl">{prompts[index]?.text}</h2>
        <form onSubmit={submit} className="mt-5 flex gap-2">
          <input
            autoFocus
            value={input}
            disabled={locked}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Your answer"
            className="min-w-0 flex-1 rounded-lg border border-line bg-dusk px-3 py-3 text-cream outline-none"
          />
          <button
            type="submit"
            disabled={locked}
            className="rounded-lg bg-clay px-4 py-3 font-semibold text-dusk disabled:opacity-40"
          >
            Ride
          </button>
        </form>
        <p className={`mt-3 min-h-6 text-sm ${bad ? "text-clay" : "text-sand"}`}>{note}</p>
      </section>
      <button type="button" onClick={onQuit} className="mt-4 self-start py-2 text-sm text-sand">
        Back to camp
      </button>
      <div className="pointer-events-none fixed inset-x-0 bottom-0 z-10 h-36 sm:h-44">
        <div
          className="absolute bottom-1 w-28 transition-all duration-700 ease-out sm:w-40"
          style={{ left: `${4 + (max ? score / max : 0) * 68}%` }}
        >
          {riding && (
            <span
              className="absolute top-8 -left-4 h-2 w-8 rounded-full bg-sand/70"
              style={{ animation: "dust 700ms ease-out" }}
            />
          )}
          <img src="/rider.png" alt="" className="w-full" />
        </div>
      </div>
    </div>
  );
}

function ResultsView({ result, onHome }: { result: RoundResult; onHome: () => void }) {
  const rank = rankFor(result.score, result.max);
  return (
    <div className="mb-40 flex flex-1 flex-col">
      <p className="text-sm tracking-[0.2em] text-sand uppercase">End of the trail</p>
      <p className="mt-2 font-display text-6xl">{result.score * 10}</p>
      <p className="text-sand">miles</p>
      <p className="mt-3 w-fit rounded-full bg-clay px-4 py-1 font-semibold text-dusk">{rank.name}</p>
      <ul className="mt-6 divide-y divide-line overflow-hidden rounded-2xl bg-ink/85">
        {result.logs.map((log, i) => (
          <li key={i} className="flex items-start justify-between gap-3 px-4 py-3 text-sm">
            <span>
              <span className="block text-sand">{log.prompt}</span>
              {log.answer}
            </span>
            <span className="shrink-0 text-right text-sand">
              {log.points ? `${log.points} pts` : "miss"}
              <span className="block">{log.note}</span>
            </span>
          </li>
        ))}
      </ul>
      <button type="button" onClick={onHome} className="mt-6 w-fit rounded-lg bg-clay px-5 py-3 font-semibold text-dusk">
        Back to camp
      </button>
    </div>
  );
}

function Editor({
  bank,
  code,
  onChange,
  onCode,
  onClose,
}: {
  bank: Bank;
  code: string;
  onChange: (bank: Bank) => void;
  onCode: (code: string) => void;
  onClose: () => void;
}) {
  const [nextCode, setNextCode] = useState("");
  const [codeNote, setCodeNote] = useState("");

  return (
    <div className="mb-8 flex flex-1 flex-col gap-4">
      <div className="flex items-end justify-between gap-3">
        <div>
          <p className="text-sm tracking-[0.18em] text-sand uppercase">Trail book</p>
          <h2 className="font-display text-4xl">Your questions</h2>
        </div>
        <button type="button" onClick={onClose} className="rounded-lg bg-clay px-4 py-2 font-semibold text-dusk">
          Done
        </button>
      </div>
      <p className="max-w-xl text-sm text-sand">
        This is the only ride. Add a prompt, then every answer that should count, with how rare it is.
        10 is what everyone blurts out. 100 is the one almost nobody will type.
      </p>
      <div className="flex flex-wrap items-end gap-2 rounded-xl bg-ink/85 p-3">
        <label className="flex min-w-48 flex-1 flex-col text-sm text-sand">
          New code {code === DEFAULT_CODE ? "(now deepcut)" : ""}
          <input
            value={nextCode}
            onChange={(e) => setNextCode(e.target.value)}
            className="mt-1 rounded-lg border border-line bg-dusk px-3 py-2 text-cream"
            placeholder="At least 3 characters"
          />
        </label>
        <button
          type="button"
          className="rounded-lg border border-sand/40 px-4 py-2"
          onClick={() => {
            const trimmed = nextCode.trim();
            if (trimmed.length < 3) {
              setCodeNote("Use at least 3 characters.");
              return;
            }
            onCode(trimmed);
            setNextCode("");
            setCodeNote("Code updated. Write it down.");
          }}
        >
          Save code
        </button>
        {codeNote && <span className="pb-2 text-sm text-sand">{codeNote}</span>}
      </div>
      {bank.prompts.length === 0 && (
        <p className="rounded-xl border border-dashed border-sand/40 px-4 py-6 text-sand">
          The trail is empty. Add the first question.
        </p>
      )}
      {bank.prompts.map((prompt, i) => (
        <PromptCard
          key={prompt.id}
          index={i}
          prompt={prompt}
          onChange={(next) =>
            onChange({ prompts: bank.prompts.map((p) => (p.id === prompt.id ? next : p)) })
          }
          onRemove={() => onChange({ prompts: bank.prompts.filter((p) => p.id !== prompt.id) })}
        />
      ))}
      <button
        type="button"
        onClick={() =>
          onChange({
            prompts: [
              ...bank.prompts,
              { id: uid(), text: "", answers: [{ id: uid(), text: "", points: 10 }] },
            ],
          })
        }
        className="inline-flex items-center justify-center gap-2 rounded-xl border border-dashed border-sand/50 py-3 text-sand"
      >
        <Plus size={18} /> Add question
      </button>
    </div>
  );
}

function PromptCard({
  index,
  prompt,
  onChange,
  onRemove,
}: {
  index: number;
  prompt: Prompt;
  onChange: (prompt: Prompt) => void;
  onRemove: () => void;
}) {
  function setAnswer(id: string, answer: Answer) {
    onChange({ ...prompt, answers: prompt.answers.map((a) => (a.id === id ? answer : a)) });
  }
  return (
    <article className="rounded-2xl bg-ink/85 p-4">
      <div className="flex items-center justify-between">
        <h3 className="font-display text-2xl">Question {index + 1}</h3>
        <button type="button" onClick={onRemove} className="rounded-lg p-2 text-sand" aria-label="Remove question">
          <Trash2 size={18} />
        </button>
      </div>
      <label className="mt-2 block text-sm text-sand">
        Prompt
        <textarea
          value={prompt.text}
          onChange={(e) => onChange({ ...prompt, text: e.target.value })}
          rows={2}
          className="mt-1 w-full rounded-lg border border-line bg-dusk px-3 py-2 text-cream"
          placeholder="Name a country song about trucks"
        />
      </label>
      <div className="mt-3 flex flex-col gap-2">
        {prompt.answers.map((answer) => (
          <div key={answer.id} className="flex flex-col gap-2 sm:flex-row">
            <input
              value={answer.text}
              onChange={(e) => setAnswer(answer.id, { ...answer, text: e.target.value })}
              className="min-w-0 flex-1 rounded-lg border border-line bg-dusk px-3 py-2 text-cream"
              placeholder="Accepted answer"
            />
            <div className="flex gap-2">
              <select
                value={answer.points}
                onChange={(e) =>
                  setAnswer(answer.id, { ...answer, points: Number(e.target.value) as Points })
                }
                className="min-w-0 flex-1 rounded-lg border border-line bg-dusk px-2 py-2 text-cream sm:flex-none"
              >
                {POINT_OPTIONS.map((p) => (
                  <option key={p} value={p}>
                    {p} · {TIER_NAME[p]}
                  </option>
                ))}
              </select>
              <button
                type="button"
                aria-label="Remove answer"
                onClick={() =>
                  onChange({ ...prompt, answers: prompt.answers.filter((a) => a.id !== answer.id) })
                }
                className="rounded-lg px-3 text-sand"
              >
                <Trash2 size={16} />
              </button>
            </div>
          </div>
        ))}
      </div>
      <button
        type="button"
        onClick={() =>
          onChange({
            ...prompt,
            answers: [...prompt.answers, { id: uid(), text: "", points: 30 }],
          })
        }
        className="mt-3 py-2 text-sm text-sand"
      >
        + Add answer
      </button>
    </article>
  );
}
