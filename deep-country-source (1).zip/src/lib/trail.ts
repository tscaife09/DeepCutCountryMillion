export const POINT_OPTIONS = [10, 15, 30, 60, 85, 100] as const;
export type Points = (typeof POINT_OPTIONS)[number];

export const TIER_NAME: Record<Points, string> = {
  10: "Boot Scootin'",
  15: "Too Clever",
  30: "Honky Tonk",
  60: "Rare Cut",
  85: "Deep Cut",
  100: "One in a Million",
};

export const ROUND_SECONDS = 25;
export const DEFAULT_CODE = "deepcut";

const BANK_KEY = "deep-country-bank-v1";
const CODE_KEY = "deep-country-code-v1";

export type Answer = { id: string; text: string; points: Points };
export type Prompt = { id: string; text: string; answers: Answer[] };
export type Bank = { prompts: Prompt[] };

export function uid() {
  return Math.random().toString(36).slice(2, 10);
}

export function emptyBank(): Bank {
  return { prompts: [] };
}

export function loadBank(): Bank {
  if (typeof localStorage === "undefined") return emptyBank();
  try {
    const raw = localStorage.getItem(BANK_KEY);
    if (!raw) return emptyBank();
    const parsed = JSON.parse(raw) as Bank;
    if (!parsed || !Array.isArray(parsed.prompts)) return emptyBank();
    return {
      prompts: parsed.prompts
        .filter((p) => p && typeof p.text === "string" && Array.isArray(p.answers))
        .map((p) => ({
          id: typeof p.id === "string" ? p.id : uid(),
          text: p.text,
          answers: p.answers
            .filter((a) => a && typeof a.text === "string")
            .map((a) => ({
              id: typeof a.id === "string" ? a.id : uid(),
              text: a.text,
              points: POINT_OPTIONS.includes(a.points) ? a.points : 30,
            })),
        })),
    };
  } catch {
    return emptyBank();
  }
}

export function saveBank(bank: Bank) {
  localStorage.setItem(BANK_KEY, JSON.stringify(bank));
}

export function loadCode(): string {
  if (typeof localStorage === "undefined") return DEFAULT_CODE;
  return localStorage.getItem(CODE_KEY) || DEFAULT_CODE;
}

export function saveCode(code: string) {
  localStorage.setItem(CODE_KEY, code.trim() || DEFAULT_CODE);
}

export function playablePrompts(bank: Bank): Prompt[] {
  return bank.prompts
    .map((p) => ({
      ...p,
      text: p.text.trim(),
      answers: p.answers.filter((a) => a.text.trim()),
    }))
    .filter((p) => p.text && p.answers.length > 0);
}

export function normalize(input: string) {
  return input
    .toLowerCase()
    .replace(/[’']/g, "")
    .replace(/&/g, " and ")
    .replace(/[^a-z0-9\s]/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function levenshtein(a: string, b: string) {
  const m = a.length;
  const n = b.length;
  const row = new Array<number>(n + 1);
  for (let j = 0; j <= n; j++) row[j] = j;
  for (let i = 1; i <= m; i++) {
    let prev = i - 1;
    row[0] = i;
    for (let j = 1; j <= n; j++) {
      const tmp = row[j];
      const cost = a[i - 1] === b[j - 1] ? 0 : 1;
      row[j] = Math.min(row[j] + 1, row[j - 1] + 1, prev + cost);
      prev = tmp;
    }
  }
  return row[n]!;
}

export type Hit = { points: Points; canonical: string; fuzzy: boolean };

/** Exact match, or a close spelling. Short guesses never fuzzy-match longer answers. */
export function matchAnswer(input: string, answers: Answer[]): Hit | null {
  const key = normalize(input);
  if (!key) return null;

  const entries = answers
    .map((a) => ({ raw: a.text.trim(), n: normalize(a.text), points: a.points }))
    .filter((e) => e.n);

  for (const e of entries) {
    if (e.n === key) return { points: e.points, canonical: e.raw, fuzzy: false };
  }

  // "a", "an", and other stubs must not latch onto a real answer.
  if (key.length < 4) return null;

  let best: { entry: (typeof entries)[number]; dist: number } | null = null;
  for (const e of entries) {
    if (e.n.length < 4) continue;
    const longer = Math.max(key.length, e.n.length);
    const shorter = Math.min(key.length, e.n.length);
    if (shorter / longer < 0.75) continue;
    const dist = levenshtein(key, e.n);
    const limit = longer <= 6 ? 1 : longer <= 12 ? 2 : 3;
    if (dist > 0 && dist <= limit && (!best || dist < best.dist)) {
      best = { entry: e, dist };
    }
  }
  if (!best) return null;
  return { points: best.entry.points, canonical: best.entry.raw, fuzzy: true };
}

export function rankFor(score: number, max: number) {
  const pct = max <= 0 ? 0 : score / max;
  if (pct >= 0.64) return { name: "One in a Million", tone: "clay" as const };
  if (pct >= 0.5) return { name: "Deep Cut", tone: "mesa" as const };
  if (pct >= 0.36) return { name: "Rare Cut", tone: "sage" as const };
  if (pct >= 0.22) return { name: "Honky Tonk", tone: "sand" as const };
  return { name: "Boot Scootin'", tone: "line" as const };
}
