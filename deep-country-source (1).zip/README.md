# Deep Country

Rare-answer country trivia. The trail book starting code is `deepcut`.

```bash
npm install
npm run dev
```

Deploy on Vercel from this repo. GitHub Pages cannot run this app.
